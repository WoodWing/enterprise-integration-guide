﻿#targetengine "session";

#include "json2.jsxinc"

main();

function main() {
    // Get publication date of the brand with id '5' and the issue with id '16'.
    getPublicationDate("5", "16");
}

/**
 * Compose the url of the server including the JSON protocol 
 */
function getServerUrl() {
    var serverUrl = app.entSession.activeUrl;

    if (serverUrl.indexOf("?") == -1) {
        serverUrl += "?protocol=JSON";
    } else {
        serverUrl += "&protocol=JSON";
    }
    return serverUrl;
}

/**
 * getPublication date for a brand and issue
 */
function getPublicationDate(brandID, issueID) {

    var publicationDate = "";

    var getPubsRequest;
    if (brandID == "") {
        getPubsRequest = {
            "method": "GetPublications",
            "id": "1",
            "params": [
                {
                    "Ticket": app.entSession.activeTicket,
                    "RequestInfo": ["PubChannels"]
                }
            ],
            "jsonrpc": "2.0"
        };
    }
    else {
        getPubsRequest = {
            "method": "GetPublications",
            "id": "1",
            "params": [
                {
                    "Ticket": app.entSession.activeTicket,
                    "IDs": [brandID],
                    "RequestInfo": ["PubChannels"]
                }
            ],
            "jsonrpc": "2.0"
        };
    }
    var response = JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(getPubsRequest)));

    for (var p = 0; p < response.result.Publications.length; p++) {
        var pub = response.result.Publications[p];
        for (var c = 0; c < pub.PubChannels.length; c++) {
            var pubChannel = pub.PubChannels[c];
            for (var i = 0; i < pubChannel.Issues.length; i++) {
                var issue = pubChannel.Issues[i];
                if (issue.Id == issueID) {
                    publicationDate = issue.PublicationDate;
                    break;
                }
            }
        }
    }
    alert("Publication Date = [" + publicationDate + "]");
}

