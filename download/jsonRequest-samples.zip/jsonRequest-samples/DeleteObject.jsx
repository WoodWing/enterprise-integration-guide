﻿
#include "json2.jsxinc"

var url = app.entSession.activeUrl + "?protocol=JSON";

// Delete object with object ID '14955'
var objectID = "14955";

var p = {
    "Ticket": app.entSession.activeTicket,
    "IDs": [
        objectID
    ],
    "Permanent": false,
    "Areas": [
        "Workflow"
    ]
};

var req = {
    method: 'DeleteObjects',
    id: "1",
    params: [p]
};


var data = JSON.stringify(req);

var resp = app.jsonRequest(url, data);

