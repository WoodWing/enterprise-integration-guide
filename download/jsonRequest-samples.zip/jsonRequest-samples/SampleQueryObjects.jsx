﻿#targetengine "session";

#include "json2.jsxinc"

main();

function main() {
	// Perform a global query for images containing the string 'light' in their name
	performQuery("", "", "image", "light");
	// Perform a query in the brand 'WW News' for images containing the string 'beach' in their name
	// performQuery ( "WW News", "", "image", "beach" );
}

/**
 * Compose the url of the server including the JSON protocol 
 */
function getServerUrl() {
	var serverUrl = app.entSession.activeUrl;

	if (serverUrl.indexOf("?") == -1) {
		serverUrl += "?protocol=JSON";
	} else {
		serverUrl += "&protocol=JSON";
	}
	return serverUrl;
}

/**
 * Perform query on brand, issue, type and object name 
 */
function performQuery(brandName, issueName, typeName, objectName) {
	var queryObjectsRequest = {
		"method": "QueryObjects",
		"id": "1",
		"params": [
			{
				"Params": [
				],
				"FirstEntry": 1,
				"MinimalProps": [
					"ID",
					"Name",
					"Type",
					"Category",
					"Issues",
					"State"
				],
				"Order": [
					{
						"__classname__": "QueryOrder",
						"Property": "Name",
						"Direction": true
					}
				],
				"Ticket": app.entSession.activeTicket
			}
		],
		"jsonrpc": "2.0"
	};

	if (brandName != "") {
		queryObjectsRequest.params[0].Params.push({
			"Property": "Publication",
			"Value": brandName,
			"Operation": "=",
			"__classname__": "QueryParam"
		});
	}

	if (issueName != "") {
		queryObjectsRequest.params[0].Params.push({
			"Property": "Issue",
			"Value": issueName,
			"Operation": "=",
			"__classname__": "QueryParam"
		});
	}

	if (typeName != "") {
		queryObjectsRequest.params[0].Params.push({
			"Property": "Type",
			"Value": typeName,
			"Operation": "=",
			"__classname__": "QueryParam"
		});
	}

	if (objectName != "") {
		queryObjectsRequest.params[0].Params.push({
			"Property": "Name",
			"Value": objectName,
			"Operation": "contains",
			"__classname__": "QueryParam"
		});
	}

	var response = JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(queryObjectsRequest)));

	var ids = new Array();
	var names = new Array();
	var categories = new Array();
	var states = new Array();
	var issues = new Array();
	var idIndex, nameIndex, catIndex, stateIndex, issuesIndex;

	for (var i = 0; i < response.result.Columns.length; i++) {
		if (response.result.Columns[i].Name == "ID") {
			idIndex = i;
		}
		else if (response.result.Columns[i].Name == "Name") {
			nameIndex = i;
		}
		else if (response.result.Columns[i].Name == "Category") {
			catIndex = i;
		}
		else if (response.result.Columns[i].Name == "State") {
			stateIndex = i;
		}
		else if (response.result.Columns[i].Name == "Issues") {
			issuesIndex = i;
		}
	}

	for (var j = 0; j < response.result.Rows.length; j++) {
		ids.push(response.result.Rows[j][idIndex]);
		names.push(response.result.Rows[j][nameIndex]);
		categories.push(response.result.Rows[j][catIndex]);
		states.push(response.result.Rows[j][stateIndex]);
		issues.push(response.result.Rows[j][issuesIndex]);
	}

	var message = "Number of objects found = " + names.length + "\n";
	for (var k = 0; k < names.length; k++) {
		message += "Object [" + ids[k] + "] = " + names[k] + "; cat = " + categories[k] + "; issues = " + issues[k] + "; state = " + states[k] + "\n";
	}

	alert(message);
}

